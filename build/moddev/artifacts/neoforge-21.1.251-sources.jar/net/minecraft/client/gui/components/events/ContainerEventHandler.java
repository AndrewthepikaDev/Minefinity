package net.minecraft.client.gui.components.events;

import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.client.gui.ComponentPath;
import net.minecraft.client.gui.navigation.FocusNavigationEvent;
import net.minecraft.client.gui.navigation.ScreenAxis;
import net.minecraft.client.gui.navigation.ScreenDirection;
import net.minecraft.client.gui.navigation.ScreenPosition;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Vector2i;

@OnlyIn(Dist.CLIENT)
public interface ContainerEventHandler extends GuiEventListener {
    List<? extends GuiEventListener> children();

    /**
     * Returns the first event listener that intersects with the mouse coordinates.
     */
    default Optional<GuiEventListener> getChildAt(double mouseX, double mouseY) {
        for (GuiEventListener guieventlistener : this.children()) {
            if (guieventlistener.isMouseOver(mouseX, mouseY)) {
                return Optional.of(guieventlistener);
            }
        }

        return Optional.empty();
    }

    @Override
    default boolean mouseClicked(double p_94695_, double p_94696_, int p_94697_) {
        for (GuiEventListener guieventlistener : this.children()) {
            if (guieventlistener.mouseClicked(p_94695_, p_94696_, p_94697_)) {
                this.setFocused(guieventlistener);
                if (p_94697_ == 0) {
                    this.setDragging(true);
                }

                return true;
            }
        }

        return false;
    }

    @Override
    default boolean mouseReleased(double p_94722_, double p_94723_, int p_94724_) {
        if (p_94724_ == 0 && this.isDragging()) {
            this.setDragging(false);
            if (this.getFocused() != null) {
                return this.getFocused().mouseReleased(p_94722_, p_94723_, p_94724_);
            }
        }

        return this.getChildAt(p_94722_, p_94723_).filter(p_94708_ -> p_94708_.mouseReleased(p_94722_, p_94723_, p_94724_)).isPresent();
    }

    @Override
    default boolean mouseDragged(double p_94699_, double p_94700_, int p_94701_, double p_94702_, double p_94703_) {
        return this.getFocused() != null && this.isDragging() && p_94701_ == 0
            ? this.getFocused().mouseDragged(p_94699_, p_94700_, p_94701_, p_94702_, p_94703_)
            : false;
    }

    boolean isDragging();

    /**
     * Sets if the GUI element is dragging or not.
     *
     * @param isDragging the dragging state of the GUI element.
     */
    void setDragging(boolean isDragging);

    @Override
    default boolean mouseScrolled(double p_94686_, double p_94687_, double p_94688_, double p_294830_) {
        return this.getChildAt(p_94686_, p_94687_).filter(p_293596_ -> p_293596_.mouseScrolled(p_94686_, p_94687_, p_94688_, p_294830_)).isPresent();
    }

    @Override
    default boolean keyPressed(int p_94710_, int p_94711_, int p_94712_) {
        return this.getFocused() != null && this.getFocused().keyPressed(p_94710_, p_94711_, p_94712_);
    }

    @Override
    default boolean keyReleased(int p_94715_, int p_94716_, int p_94717_) {
        return this.getFocused() != null && this.getFocused().keyReleased(p_94715_, p_94716_, p_94717_);
    }

    @Override
    default boolean charTyped(char p_94683_, int p_94684_) {
        return this.getFocused() != null && this.getFocused().charTyped(p_94683_, p_94684_);
    }

    @Nullable
    GuiEventListener getFocused();

    /**
     * Sets the focus state of the GUI element.
     *
     * @param focused the focused GUI element.
     */
    void setFocused(@Nullable GuiEventListener focused);

    /**
     * Sets the focus state of the GUI element.
     */
    @Override
    default void setFocused(boolean p_265504_) {
    }

    @Override
    default boolean isFocused() {
        return this.getFocused() != null;
    }

    @Nullable
    @Override
    default ComponentPath getCurrentFocusPath() {
        GuiEventListener guieventlistener = this.getFocused();
        return guieventlistener != null ? ComponentPath.path(this, guieventlistener.getCurrentFocusPath()) : null;
    }

    /**
     * Retrieves the next focus path based on the given focus navigation event.
     * <p>
     * @return The next focus path as a ComponentPath, or {@code null} if there is no next focus path.
     */
    @Nullable
    @Override
    default ComponentPath nextFocusPath(FocusNavigationEvent p_265668_) {
        GuiEventListener guieventlistener = this.getFocused();
        if (guieventlistener != null) {
            ComponentPath componentpath = guieventlistener.nextFocusPath(p_265668_);
            if (componentpath != null) {
                return ComponentPath.path(this, componentpath);
            }
        }

        if (p_265668_ instanceof FocusNavigationEvent.TabNavigation focusnavigationevent$tabnavigation) {
            return this.handleTabNavigation(focusnavigationevent$tabnavigation);
        } else {
            return p_265668_ instanceof FocusNavigationEvent.ArrowNavigation focusnavigationevent$arrownavigation
                ? this.handleArrowNavigation(focusnavigationevent$arrownavigation)
                : null;
        }
    }

    /**
     * Handles tab-based navigation events.
     * <p>
     * @return The next focus path for tab navigation, or {@code null} if no suitable path is found.
     *
     * @param tabNavigation The tab navigation event.
     */
    @Nullable
    private ComponentPath handleTabNavigation(FocusNavigationEvent.TabNavigation tabNavigation) {
        boolean flag = tabNavigation.forward();
        GuiEventListener guieventlistener = this.getFocused();
        List<? extends GuiEventListener> list = new ArrayList<>(this.children());
        Collections.sort(list, Comparator.comparingInt(p_344153_ -> p_344153_.getTabOrderGroup()));
        int j = list.indexOf(guieventlistener);
        int i;
        if (guieventlistener != null && j >= 0) {
            i = j + (flag ? 1 : 0);
        } else if (flag) {
            i = 0;
        } else {
            i = list.size();
        }

        ListIterator<? extends GuiEventListener> listiterator = list.listIterator(i);
        BooleanSupplier booleansupplier = flag ? listiterator::hasNext : listiterator::hasPrevious;
        Supplier<? extends GuiEventListener> supplier = flag ? listiterator::next : listiterator::previous;

        while (booleansupplier.getAsBoolean()) {
            GuiEventListener guieventlistener1 = supplier.get();
            ComponentPath componentpath = guieventlistener1.nextFocusPath(tabNavigation);
            if (componentpath != null) {
                return ComponentPath.path(this, componentpath);
            }
        }

        return null;
    }

    /**
     * Handles arrow-based navigation events.
     * <p>
     * @return The next focus path for arrow navigation, or {@code null} if no suitable path is found.
     *
     * @param arrowNavigation The arrow navigation event.
     */
    @Nullable
    private ComponentPath handleArrowNavigation(FocusNavigationEvent.ArrowNavigation arrowNavigation) {
        GuiEventListener guieventlistener = this.getFocused();
        if (guieventlistener == null) {
            ScreenDirection screendirection = arrowNavigation.direction();
            ScreenRectangle screenrectangle1 = this.getRectangle().getBorder(screendirection.getOpposite());
            return ComponentPath.path(this, this.nextFocusPathInDirection(screenrectangle1, screendirection, null, arrowNavigation));
        } else {
            ScreenRectangle screenrectangle = guieventlistener.getRectangle();
            return ComponentPath.path(this, this.nextFocusPathInDirection(screenrectangle, arrowNavigation.direction(), guieventlistener, arrowNavigation));
        }
    }

    /**
     * Calculates the next focus path in a specific direction.
     * <p>
     * @return The next focus path in the specified direction, or {@code null} if no suitable path is found.
     *
     * @param rectangle The screen rectangle.
     * @param direction The direction of navigation.
     * @param listener  The currently focused GUI event listener.
     * @param event     The focus navigation event.
     */
    @Nullable
    private ComponentPath nextFocusPathInDirection(
        ScreenRectangle rectangle, ScreenDirection direction, @Nullable GuiEventListener listener, FocusNavigationEvent event
    ) {
        ScreenAxis screenaxis = direction.getAxis();
        ScreenAxis screenaxis1 = screenaxis.orthogonal();
        ScreenDirection screendirection = screenaxis1.getPositive();
        int i = rectangle.getBoundInDirection(direction.getOpposite());
        List<GuiEventListener> list = new ArrayList<>();

        for (GuiEventListener guieventlistener : this.children()) {
            if (guieventlistener != listener) {
                ScreenRectangle screenrectangle = guieventlistener.getRectangle();
                if (screenrectangle.overlapsInAxis(rectangle, screenaxis1)) {
                    int j = screenrectangle.getBoundInDirection(direction.getOpposite());
                    if (direction.isAfter(j, i)) {
                        list.add(guieventlistener);
                    } else if (j == i && direction.isAfter(screenrectangle.getBoundInDirection(direction), rectangle.getBoundInDirection(direction))) {
                        list.add(guieventlistener);
                    }
                }
            }
        }

        Comparator<GuiEventListener> comparator = Comparator.comparing(
            p_264674_ -> p_264674_.getRectangle().getBoundInDirection(direction.getOpposite()), direction.coordinateValueComparator()
        );
        Comparator<GuiEventListener> comparator1 = Comparator.comparing(
            p_264676_ -> p_264676_.getRectangle().getBoundInDirection(screendirection.getOpposite()), screendirection.coordinateValueComparator()
        );
        list.sort(comparator.thenComparing(comparator1));

        for (GuiEventListener guieventlistener1 : list) {
            ComponentPath componentpath = guieventlistener1.nextFocusPath(event);
            if (componentpath != null) {
                return componentpath;
            }
        }

        return this.nextFocusPathVaguelyInDirection(rectangle, direction, listener, event);
    }

    /**
     * Calculates the next focus path in a vague direction.
     * <p>
     * @return The next focus path in the vague direction, or {@code null} if no suitable path is found.
     *
     * @param rectangle The screen rectangle.
     * @param direction The direction of navigation.
     * @param listener  The currently focused GUI event listener.
     * @param event     The focus navigation event.
     */
    @Nullable
    private ComponentPath nextFocusPathVaguelyInDirection(
        ScreenRectangle rectangle, ScreenDirection direction, @Nullable GuiEventListener listener, FocusNavigationEvent event
    ) {
        ScreenAxis screenaxis = direction.getAxis();
        ScreenAxis screenaxis1 = screenaxis.orthogonal();
        List<Pair<GuiEventListener, Long>> list = new ArrayList<>();
        ScreenPosition screenposition = ScreenPosition.of(screenaxis, rectangle.getBoundInDirection(direction), rectangle.getCenterInAxis(screenaxis1));

        for (GuiEventListener guieventlistener : this.children()) {
            if (guieventlistener != listener) {
                ScreenRectangle screenrectangle = guieventlistener.getRectangle();
                ScreenPosition screenposition1 = ScreenPosition.of(
                    screenaxis, screenrectangle.getBoundInDirection(direction.getOpposite()), screenrectangle.getCenterInAxis(screenaxis1)
                );
                if (direction.isAfter(screenposition1.getCoordinate(screenaxis), screenposition.getCoordinate(screenaxis))) {
                    long i = Vector2i.distanceSquared(screenposition.x(), screenposition.y(), screenposition1.x(), screenposition1.y());
                    list.add(Pair.of(guieventlistener, i));
                }
            }
        }

        list.sort(Comparator.comparingDouble(Pair::getSecond));

        for (Pair<GuiEventListener, Long> pair : list) {
            ComponentPath componentpath = pair.getFirst().nextFocusPath(event);
            if (componentpath != null) {
                return componentpath;
            }
        }

        return null;
    }
}
